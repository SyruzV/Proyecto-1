﻿Console.WriteLine("Guest the Number!");
Random secretNumber = new Random();

int from = 0;
int to = 0;
int guess;
bool won = false;
int vidas = 0;
int option = 0;

Console.WriteLine("1.Facil");
Console.WriteLine("2.Medio");
Console.WriteLine("3.Dificil");
option = Convert.ToInt16(Console.ReadLine());
if (option == 1) {
    vidas = 10;
    to = 100;
}
if (option == 2) {
    vidas = 5;
    to = 500;
}
if (option == 3) {
    vidas = 3;
    to = 10000;
}

int secretNumber2 = secretNumber.Next(to);
while (!won) {
    Console.WriteLine("Think on a number between " + from + " and " + to + "...");
    string? input = Console.ReadLine();

    bool isValid = int.TryParse(input, out guess);

    if (isValid)
    {
        if (secretNumber2 == guess)
        {
            Console.WriteLine("Correcto!!");
            won = true;
        } else {
            //TODO: Tell the player if the number is bigger then, or less than the secret number
            Console.WriteLine("Numero incorrecto.");
            vidas = vidas - 1;
            if (secretNumber2 > guess) {Console.WriteLine("El numero es mayor");}
            if (secretNumber2 < guess) {Console.WriteLine("El numero es menor");}
            }
            if (vidas == 0) {
                won = true;
            }
        } else {
            Console.WriteLine("Valor ingresado es incorrecto, intente de nuevo.");
    }
}
if (vidas == 0) {
    Console.WriteLine("Has perdido :(");
     }
Console.WriteLine("Fin del juego");
